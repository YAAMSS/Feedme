package com.segui.dinnerdecider

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProviders
import com.segui.models.Food
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity  : AppCompatActivity() {

    private val foodList = arrayListOf("Chinese", "Hamburger", "Pizza", "McDonalds", "Barros Pizza")

    lateinit var viewModel: FoodViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel =
        val db: FoodDatabase = FoodDatabase.getInstance(applicationContext)
        val foodList = db.foodDao().getAll()
        Log.d("foodlist", foodList.toString())


        decideBtn.setOnClickListener {
            val random = Random()
            val randomFood = random.nextInt(foodList.count())
            selectedFoodTxt.text = foodList[randomFood].foodName
        }

        addFoodBtn.setOnClickListener {
            //val newFood = addFoodTxt.text.toString()
            val newFood = Food(addFoodTxt.text.toString())
            db.foodDao().insert(newFood)
            addFoodTxt.text?.clear()
            println(foodList)
        }


    }
}
